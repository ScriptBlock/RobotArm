/*
 * Visualization source
 */
define([
            'jquery',
            'underscore',
            'api/SplunkVisualizationBase',
            'api/SplunkVisualizationUtils',
	    'three',
            'three-math',
            'tween.js',
            'mathjs'
       
            // Add required assets to this list
        ],
        function(
            $,
            _,
            SplunkVisualizationBase,
            vizUtils,
            THREE,
            Math,
            TWEEN,
            mathjs
        ) {

    var hasViz = false;


var container;

var counter=0;

var camera, scene, renderer;

var activeTween;

var mouseX = 0, mouseY = 0;


var commonMaterial = new THREE.MeshBasicMaterial( {color: "lightgrey", vertexColors: THREE.FaceColors, wireframe: false} );
var redMaterial = new THREE.MeshBasicMaterial( {color: "red", vertexColors: THREE.FaceColors, wireframe: true} );
var blueMaterial = new THREE.MeshBasicMaterial( {color: "lightblue", vertexColors: THREE.FaceColors, wireframe: true} );


var baseCylinderGeom, base;
var baseCylinderAngleGeom, baseAngle;
var mainArmCylinderGeom, mainArm;
var mainArmAngleGeom, mainArmAngle;
var subArmCylinderGeom, subArm;
var subArmAngleGeom, subArmAngle;
var handOneCylinderGeom, handOneCylinder;

var handTwoCylinderGeom, handTwoCylinder;

var wristCylinderGeom, wristCylinder;
var fingerOneGeom, fingerOne;
var fingerTwoGeom, fingerTwo;


function animate() {
	requestAnimationFrame(animate);
	render();
	TWEEN.update();

}

function render() {
	camera.lookAt(scene.position);
	renderer.render(scene, camera);

}


    // Extend from SplunkVisualizationBase
    return SplunkVisualizationBase.extend({
  

        initialize: function() {
            SplunkVisualizationBase.prototype.initialize.apply(this, arguments);
            this.$el = $(this.el);
            hasViz = false;
            this.$el.addClass('rotator');
            // Initialization logic goes here

	
	//camera = new THREE.PerspectiveCamera( 80, window.innerWidth/window.innerHeight, 0.1, 1000 );	
	//camera = new THREE.PerspectiveCamera(45, this.$el.innerWidth/this.$el.innerHeight, 0.1, 1000);
	//var iw = this.$el.offset();
	//console.log(this.$el);
	//console.log(iw);
	//camera.position.y = 5;
	//camera.position.z = 10;


	scene = new THREE.Scene();

	var ambient = new THREE.AmbientLight( 0x040404 );
	scene.add( ambient );

	var pointLight = new THREE.PointLight( 0x404040 );
	pointLight.position.set( 0, 100, 100 );
	scene.add( pointLight );

	
	baseCylinderGeom = new THREE.CylinderGeometry(1,1,3,32);
	base = new THREE.Mesh(baseCylinderGeom, redMaterial);

	scene.add(base);

	
	baseCylinderAngleGeom = new THREE.CylinderGeometry(0.75,0.75,1,32);
	baseAngle = new THREE.Mesh(baseCylinderAngleGeom, blueMaterial);
	baseAngle.position.x = 1.25;
	baseAngle.position.y = 0.75;
	baseAngle.rotateZ(THREE.Math.degToRad(90));
	base.add(baseAngle);

	
	mainArmCylinderGeom = new THREE.CylinderGeometry(0.5,0.5,4.5,32);
	mainArmCylinderGeom.translate(0, 1.75,0);
	mainArm = new THREE.Mesh(mainArmCylinderGeom,redMaterial);
	mainArm.position.x = 2.15;
	mainArm.position.y = 1;
	base.add(mainArm);	

	
	mainArmAngleGeom = new THREE.CylinderGeometry(0.5, 0.5, 0.5, 32);
	mainArmAngle = new THREE.Mesh(mainArmAngleGeom,blueMaterial);
	mainArmAngle.position.x = -0.75;
	mainArmAngle.position.y = 3.45;
	mainArmAngle.rotateZ(THREE.Math.degToRad(90));
	mainArm.add(mainArmAngle);

	
	subArmCylinderGeom = new THREE.CylinderGeometry(0.35,0.35,3,32);
	subArmCylinderGeom.translate(0, 1.2,0);
	subArm = new THREE.Mesh(subArmCylinderGeom,redMaterial);
	subArm.position.x = -1.35;
	subArm.position.y = 3.5;
	mainArm.add(subArm);	

	
	subArmAngleGeom = new THREE.CylinderGeometry(0.25, 0.25, 0.5,32);
	subArmAngle = new THREE.Mesh(subArmAngleGeom, blueMaterial);
	subArmAngle.position.x = 0.5;
	subArmAngle.position.y = 2.4;
	subArmAngle.rotateZ(THREE.Math.degToRad(90));
	subArm.add(subArmAngle);

	handOneCylinderGeom = new THREE.CylinderGeometry(0.25,0.25,0.65, 32);
	handOneCylinderGeom.translate(0,0.15,0);
	handOneCylinder = new THREE.Mesh(handOneCylinderGeom, redMaterial);
	handOneCylinder.position.y = 2.4;
	handOneCylinder.position.x = 1;
	subArm.add(handOneCylinder);


	handTwoCylinderGeom = new THREE.CylinderGeometry(0.25,0.25,0.55, 32);
	handTwoCylinder = new THREE.Mesh(handTwoCylinderGeom, blueMaterial);
	handTwoCylinder.rotateX(THREE.Math.degToRad(90));
	handTwoCylinder.position.y = 0.65;
	handOneCylinder.add(handTwoCylinder);

	wristCylinderGeom = new THREE.CylinderGeometry(0.25,0.25,0.25,32);
	wristCylinder = new THREE.Mesh(wristCylinderGeom, redMaterial);
	wristCylinder.position.y = 0.4;
	handTwoCylinder.add(wristCylinder);


	fingerOneGeom = new THREE.BoxGeometry(0.1, 0.3, 0.1);
	fingerOne = new THREE.Mesh(fingerOneGeom, blueMaterial);
	fingerOne.position.y = 0.3;
	fingerOne.position.x = -0.1;
	wristCylinder.add(fingerOne);

	fingerTwoGeom = new THREE.BoxGeometry(0.1,0.3, 0.1);
	fingerTwo = new THREE.Mesh(fingerTwoGeom, blueMaterial);
	fingerTwo.position.y = 0.3;
	fingerTwo.position.x = 0.1;
	wristCylinder.add(fingerTwo);

	console.log(this.$el.innerWidth());

	renderer = new THREE.WebGLRenderer();
	renderer.setPixelRatio( window.devicePixelRatio );
	//renderer.setSize( this.$el.innerWidth, this.$el.innerHeight );
	renderer.setSize(window.innerWidth, window.innerHeight);
	document.body.appendChild( renderer.domElement );
	this.$el.append(renderer.domElement);

	camera = new THREE.PerspectiveCamera(80, window.innerWidth/window.innerHeight, 0.1, 1000);
	camera.position.y = 10;
        camera.position.z = 10;

	animate();

        },

        // Optionally implement to format data returned from search. 
        // The returned object will be passed to updateView as 'data'
        formatData: function(data) {

            // Format data 

            return data;
        },
  
        // Implement updateView to render a visualization.
        //  'data' will be the data object returned from formatData or from the search
        //  'config' will be the configuration property object
        
        updateView: function(data, config) {
		if(!hasViz) {
            		hasViz = true;
		}

		//console.log("part: " + data.rows[0][0]);
		//console.log("rotation: " + data.rows[0][1]);		

		// Check for empty data
		if(data.rows.length < 1) { return; }
	        var actualRadians=THREE.Math.degToRad(data.rows[0][1]*mathjs.PI/180);
		switch(data.rows[0][0]) {
			case "base":

				new TWEEN.Tween({y:base.rotation.y, obj:base, tween:activeTween})
						.to({y:actualRadians}, 200)
						.onUpdate(function() { this.obj.rotation.y = this.y; })
						.easing(TWEEN.Easing.Exponential.InOut)
						.start();
				break;
			case "mainArm":
				new TWEEN.Tween({x:mainArm.rotation.x, obj:mainArm, tween:activeTween})
						.to({x:actualRadians}, 200)
						.onUpdate(function() { this.obj.rotation.x = this.x; })
						.easing(TWEEN.Easing.Exponential.InOut)
						.start();
				break;
			case "subArm":
				new TWEEN.Tween({x:subArm.rotation.x, obj:subArm, tween:activeTween})
						.to({x:actualRadians}, 200)
						.onUpdate(function() { this.obj.rotation.x = this.x; })
						.easing(TWEEN.Easing.Exponential.InOut)
						.start();
				break;
			case "handOneCylinder":
				new TWEEN.Tween({x:handOneCylinder.rotation.x, obj:handOneCylinder, tween:activeTween})
						.to({x:actualRadians}, 200)
						.onUpdate(function() { this.obj.rotation.x = this.x; })
						.easing(TWEEN.Easing.Exponential.InOut)
						.start();
				break;
			case "handTwoCylinder":
				new TWEEN.Tween({z:handTwoCylinder.rotation.z, obj:handTwoCylinder, tween:activeTween})
						.to({z:actualRadians}, 200)
						.onUpdate(function() { this.obj.rotation.z = this.z; })
						.easing(TWEEN.Easing.Exponential.InOut)
						.start();
				break;
			case "wristCylinder":
				new TWEEN.Tween({y:wristCylinder.rotation.y, obj:wristCylinder, tween:activeTween})
						.to({y:actualRadians}, 200)
						.onUpdate(function() { this.obj.rotation.y = this.y; })
						.easing(TWEEN.Easing.Exponential.InOut)
						.start();
				break;

		}
		
        },

        // Search data params
        getInitialDataParams: function() {
            return ({
                outputMode: SplunkVisualizationBase.ROW_MAJOR_OUTPUT_MODE,
                count: 10000
            });
        },

        // Override to respond to re-sizing events
        reflow: function() {}
    });
});
